//requiring path and fs modules
require('dotenv').config()

const path = require('path');
const fs = require('fs');
const csv = require('csv-parser');
const moment = require('moment');
const stripBom = require('strip-bom-stream');
var sql = require("mssql");
const sqlConfig = require('./config/sql.js')
const dateFormat = require('dateformat');
const ExportToCsv = require('export-to-csv').ExportToCsv;
const mkdirp = require('mkdirp');
const rimraf = require("rimraf");
const opcua = require("node-opcua");


const delay = (amount = number) => {
  return new Promise((resolve) => {
    setTimeout(resolve, amount);
  });
}

require('events').EventEmitter.defaultMaxListeners = 200;

const strSQLTableName = process.env.SQL_TABLE_NAME;
const SQL_TABLE_STATUS = process.env.SQL_TABLE_STATUS;

const isMoveFile = parseInt(process.env.IS_MOVE_FILE)
const PROCESS_TIME = parseInt(process.env.PROCESS_TIME)*1000;
const REMOVE_TIME = parseInt(process.env.REMOVE_TIME)*1000;
const PROCESSED_STORE = parseInt(process.env.PROCESSED_STORE)*1000;
const CHECK_CONNECT_TIME = parseInt(process.env.CHECK_CONNECT_TIME)*1000;
const BACKUP_SQL_DAY = parseInt(process.env.BACKUP_SQL_DAY);
const directoryPath = process.env.CSV_FLEXY_PATH;
const inprogressFolder = directoryPath + '\\Inprogress';
const testFoler = directoryPath + '\\TEST\\'
//*******************************************
//joining path of directory

async function run(){
	setInterval(async function(){
  	MoveFile();
    //checkConnection()
  	//await writeAckOPCUA()
  	console.log('====================================')
  }, 15000);
}
run();


async function MoveFile(){
	//passsing directoryPath and callback function
	await fs.readdir(testFoler, async function (err, files) {
  //handling error
    if (err) {
      return console.log('Unable to scan directory: ' + err);
    } 
    await files.forEach(async function (file) {      

      let currentPath = inprogressFolder + '\\'  + file + '-' + moment().format('HHmmss')+ '.csv';
      let testPath = directoryPath + '\\TEST\\' +  file ;
      
      fs.copyFileSync(testPath, currentPath);

    });
  });
}






