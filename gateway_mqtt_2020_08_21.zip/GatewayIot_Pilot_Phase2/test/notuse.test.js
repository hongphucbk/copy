const  { 
  OPCUAClient,
  resolveNodeId, 
  DataType,
  AttributeIds,
  ClientMonitoredItemGroup, 
  TimestampsToReturn
 } = require("node-opcua-client");
const opcua = require("node-opcua");


function getInitConfig(){
  fs.createReadStream('./config/site_information.txt')
    .pipe(csv({separator:';'}))
    .on('data', (data) => {
      arrAllSites.push(data) 
      // arrExportData.push(jsonExportData)
    })
    .on('end', async function(){
      arrAllSites.forEach(function(site){
        try{
          site.tagnames = site.tagnames.split('*')
          let arrTemp = []
          for ( tn of site.tagnames) 
          { 
            let _temp = JSON.parse(tn)
            arrTemp.push(_temp)
          }
          site.jsonTags = arrTemp 
          console.log(site)
        }catch(err){
          console.log(err)
          log.error('Convert tagname has error: ' + err.message)
        }
      })
    })
}

// Read data using OPC UA
async function readDataFromFlexy(){
  const connectionStrategy = {
    initialDelay: 1000,
    maxRetry: 1
  }
  const options = {
      // applicationName: "MyClient",
      connectionStrategy: connectionStrategy,
      // securityMode: MessageSecurityMode.None,
      // securityPolicy: SecurityPolicy.None,
      endpoint_must_exist: false,
  };

  arrAllSites.forEach(async function(site){
    try{
      let _arrData = []
      const client = OPCUAClient.create(options);
      const endpointUrl = 'opc.tcp://' + site.ip +':'+ site.port;

      client.on("backoff", (retry, delay) => {
        //console.log("Backoff ", retry, " next attempt in ", delay, "ms");
        client.disconnect();
      });

      client.on("connection_failed", () => {
        client.disconnect();
        //console.log("Connection failed");
        log.error("OPC UA -" + site.site_id + 'can not connect to Flexy')
        saveConnectionStatus(site.site_id, 0)
        //writeConnectionToCSV(site.site_id, 0)
      });


      // step 1 : connect to
      await client.connect(endpointUrl);
      //console.log("OPC UA connected !");
      log.info('OPC UA - '+ site.site_id + ' connected to Flexy --> at ' + moment().format("YYYY-MM-DD HH:mm:ss"))
      saveConnectionStatus(site.site_id, 1)
      //writeConnectionToCSV(site.site_id, 1)
      // Step 2 : createSession
      const session = await client.createSession({userName: site.username,password:site.password});
      // console.log("Session created !");

      // Step 4 : read a variable with readVariableValue
      //await site.tagnames.forEach(async function(tagname){
      for await (tag of site.jsonTags) {
        const dataValue2 = await session.readVariableValue("ns="+ site.namespace +";s=" + tag.name);
        //console.log("OPC UA: Tagname = " , site.site_id, tag.name, dataValue2.value.value);
        let _value = parseFloat(dataValue2.value.value).toFixed(2);
        if (_value >= tag.min && _value <= tag.max) {
          let _jsonData = {
                site_id : site.site_id,
                ip: site.ip,
                timestamp: new Date(),
                tagname: tag.sys,
                value: _value,
                created_at: new Date(),
              }
          _arrData.push(_jsonData)
        }
        
      }
      
      //await console.log(_arrData)
      let _isStoredSucess = await SaveDataToSQLServer(_arrData)
      if (_isStoredSucess) {
        log.info(site.site_id + ' SQL stored realtime data successfully')
      }else{
        log.error('SQL stored realtime data ERROR')
      }

      // close session
      await session.close();
      // disconnecting
      await client.disconnect();
      log.info('OPC UA - '+ site.site_id + ' disconnect to Flexy')

    }catch(err){
      log.error('OPC UA has error: ' + err.message)
    }
  })

}

async function writeConnectionToCSV(tag_header, site_id, value){
  if (parseInt(process.env.IS_EXPORT_TO_CSV) == 1) {
    let jsonConnectExportData = [
    {
      TimeStamp: 'TimeStamp',
      Tagname: 'Tagname',
      Value: 'Value',
    },
    {
      TimeStamp: dateFormat(new Date(), "mm/dd/yyyy HH:MM"),
      Tagname: tag_header + ':'+ site_id + '.'+ 'COMMUNICATION',
      Value: value,
    }]
    //console.log(jsonConnectExportData)
    await exportToCSVFile(site_id, 'COMMUNICATION', jsonConnectExportData)
  }
}

function exportToCSVFile(site_id, tagname, data){
  const options = { 
    fieldSeparator: ',',
    quoteStrings: '',
    decimalSeparator: '.',
    showLabels: true, 
    showTitle: false,
    title: '[Data]',
    useTextFile: false,
    useBom: false,
    useKeysAsHeaders: false,
    headers: ['[DATA]'] //<-- Won't work with useKeysAsHeaders present!
  };
  const csvExporter = new ExportToCsv(options);
  const csvData = csvExporter.generateCsv(data, true);
  var dateTime = new Date();
  dateTime = moment(dateTime).format("YYYYMMDD_HHmmss");
  let strFullPath = process.env.CSV_EXPORT_PATH + '\\DT_' + site_id + '_'  + tagname + '_' + dateTime + '.csv'
  
  try{
    fs.writeFileSync(strFullPath, csvData)
    //fs.writeFileSync(strFullPathBackup, csvData)
  }catch (err){
    //console.log('Write CSV have issue ' + err.message)
    log.error('Write CSV have issue: ' + err.message)
  }

  //for Backup
  let _strPath_Year = process.env.CSV_BACKUP_PATH +'\\' + moment().format("YYYY")
  let _strPath_Month = _strPath_Year + '\\' + moment().format("YYYY_MM")
  let _strPath_Date = _strPath_Month + '\\' + moment().format("YYYY_MM_DD")
  let _strPath_Hour = _strPath_Date + '\\' + moment().format("YYYY_MM_DD_HH")

  mkdirp.sync(_strPath_Year);
  mkdirp.sync(_strPath_Month);
  mkdirp.sync(_strPath_Date);
  mkdirp.sync(_strPath_Hour);
  let strFullPathBackup = _strPath_Hour + '\\DT_' + site_id + '_' + tagname + '_' + dateTime + '.csv'
  try{
    fs.writeFileSync(strFullPathBackup, csvData)
  }catch (err){
    console.log('Write CSV have issue ' + err.message)
    log.error('Write CSV ' + site_id + ' - ' + tagname + ' have error: ' + err.message)
  }
}
