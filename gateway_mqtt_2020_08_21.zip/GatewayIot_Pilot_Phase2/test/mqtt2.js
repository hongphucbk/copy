const moment = require('moment');
var mqtt = require('mqtt')
//var mqtt1 = require('mqtt')


//let client1  = mqtt1.connect('mqtt://127.0.0.1:1884')

let client  = mqtt.connect(process.env.MQTT_URL)
client.on('connect', function () {
  console.log('Connect MQTT')
  client.subscribe('Flexy/Data1', function (err) {
    if (!err) {
      console.log('MQTT is connected to Broker successfully')
      //client.publish('data', 'Hello mqtt')
    }
  })
})

client.on('message', async function (topic, payload) { 
  console.log(topic)
  if (topic== process.env.MQTT_TOPIC)
  {
    console.log(payload.toString())
    //client1.publish('Flexy/Data1', payload.toString())
    
  }
})


// client1.on('connect', function () {
//   console.log('Connect MQTT 1')
// })


  
  

