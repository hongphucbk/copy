var mqtt = require('mqtt')
var client  = mqtt.connect('mqtt://192.168.1.8:1883')
 
client.on('connect', function () {
  client.subscribe('presence', function (err) {
    if (!err) {
      client.publish('data', 'Hello mqtt')
    }
  })
})
 
client.on('message', function (topic, message) {
  // message is Buffer
  console.log(message.toString())
  //client.end()
})
var messageflexy =
{
	"siteid":"site2",
	"sitename":"vnsite2",
	"status":1

}
setInterval(function()
{
	client.publish('Flexy/Status', JSON.stringify(messageflexy));
	console.log("data is sending");
},1000); 