Aucontech Gateway
-----------------------